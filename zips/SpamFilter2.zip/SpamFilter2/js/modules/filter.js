export class Filter{
    // settings 
    static black_list = [];
    static white_list = [];
    static enable_ai = false;

    detect(){
        this.black_list = $('#blacklist').val().split(/[,\n]/).map(
            function(e) {
                return e.trim().toLowerCase();
            }).filter(function(e) {
                return e !== '';
            });
        this.white_list = $('#whitelist').val().split(/[,\n]/).map(
            function(e) {
                return e.trim().toLowerCase();
            }).filter(function(e) {
                return e !== '';
            });
        filter_lists(); // omit matching whitelist/blacklist terms
        filter_emails(); // filter with blacklist/whitelist
        if(this.enable_ai) heuristic_analysis(); // run heuristic analysis
    }

    filter_lists(){
        var omit_terms = $.grep(this.white_list, function(term) {
            return $.inArray(term.toLowerCase(), this.black_list) !== -1;
        });
        if(omit_terms.length > 0){
            $.notify("The following terms were found in both the whitelist and the blacklist, and will be omitted from the spam filter: " + omit_terms.join(', '),
            { className: "info", autoHideDelay: 20000 });
        }
        $.each(omit_terms, function(term) {
            var i1 = this.white_list.indexOf(term), i2 = this.black_list.indexOf(term);
            if (i1 !== -1) this.white_list.splice(i1, 1);
            if (i2 !== -1) this.black_list.splice(i2, 1);
        });
    }
    
    filter_emails(){
        if(this.black_list.length > 0) blacklist(this.black_list);
        if(this.white_list.length > 0) whitelist(this.white_list);
    }
    
    
    blacklist(terms){
        var count = 0;
        if(terms.length == 0 || terms[0] == '') return;
        $(this.emails).each(function(i, email) {
            var is_spam = terms.some(function(word) {
                return email.sender.toLowerCase().includes(word.trim().toLowerCase()) ||
                       email.subject.toLowerCase().includes(word.trim().toLowerCase()) ||
                       email.content.toLowerCase().includes(word.trim().toLowerCase());
            });
            if(is_spam){
                mark_spam(email.id, false);
                count++;
            }
        });
        if(!count) $.notify("Nothing blacklisted. Try adjusting the settings.", { className: "warn", autoHideDelay: 3000 });
        else{
            $.notify(count + " conversation(s) added to spam.", { className: "success", autoHideDelay: 3000 });
            update_tabs(true);
            update_mark_all(this.current_tab, false);
        }
    }
    
    whitelist(terms){
        var count = 0;
        if(terms.length == 0 || terms[0] == '') return;
        $(this.spam).each(function(i, message) {
            var contains_whitelist = terms.some(function(word) {
                return message.sender.toLowerCase().includes(word.trim().toLowerCase()) ||
                    message.subject.toLowerCase().includes(word.trim().toLowerCase()) ||
                    message.content.toLowerCase().includes(word.trim().toLowerCase());
            });
            if(contains_whitelist){
                mark_not_spam(message.id, false);
                count++;
            }
        });
        if(!count) $.notify("Nothing whitelisted. Try adjusting the settings.", { className: "warn", autoHideDelay: 3000 });
        else{
            $.notify(count + " conversation(s) moved to inbox.", { className: "success", autoHideDelay: 3000 });
            update_tabs(true);
            update_mark_all(this.current_tab, false);
        }
    }
}

$(function() {
    $("#heuristics").button(); // // init heuristics button, checkbox -> toggle
    $(document).on('click', '#mark-all-spam', function() { mark_all_spam();}); // marking all as spam
    $(document).on('click', '#mark-all-not-spam', function() { mark_all_not_spam();}); // mark all as not spam
  
    // heuristics on switch 
    $('#heuristics').change(function() {
      enable_ai = this.checked;
      $('.spam_prob').toggleClass('hidden');
      $('.spam_prob').each(function () {
        $(this).prop('Counter', 0).animate({ Counter: $(this).attr('data-value')}, {
            duration: 1000, easing: 'swing',
            step: function (now) { $(this).text(Math.ceil(now) + '%');}
        });
      });
    });
  });
  