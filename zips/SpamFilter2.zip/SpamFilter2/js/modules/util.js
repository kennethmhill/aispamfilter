import { Model } from './model.js';

export function fetch_results() {
    return $.ajax({ url: 'csv/emails.csv', dataType: 'text',})
            .then(function(data) { return $.csv.toObjects(data); }); // csv -> json
}

export function get_email_colors(p){
    var green = [162,193,28], yellow = [255,234,0], red = [255,0,0], tooltip = '', color = '';
        
    if(p < Model.threshold) color = interpolate_rgb(green, yellow, p/Model.threshold), tooltip = '<div class="tooltip"><span class="tooltiptext">There is a low likelihood this email is spam.</span></div>';
    else color = interpolate_rgb(yellow, red, (this.spam_prob - Model.threshold) / (1 - Model.threshold)), tooltip = '<div class="tooltip"><i class="fa fa-info-circle"></i><span class="tooltiptext">There is a '+(p*100).toFixed(2)+'% chance this email is spam. Proceed with caution.</span></div>';
        
    color1 = `rgb(${color.join(', ')})`, color2 = darken(color1, .7);
    return [color1, color2];
}

export function interpolate_rgb(color1, color2, percentage) {
    return color1.map((channel1, index) => {
        const channel2 = color2[index], inter_channel = Math.round(channel1 + percentage * (channel2 - channel1));
        return Math.min(255, Math.max(0, inter_channel)); // Ensure the value is in the valid RGB range
    });
}

export function first20(text) {
    return text.split(/\s+/).slice(0, 20).join(' '); // return first 20 words
}

export function darken(rgb, factor) {
    if (Array.isArray(rgb)) return `rgb(${rgb.map(component => Math.round(component * factor)).join(', ')})`;
    else return rgb; // return original if not array 
}

export function get_trimmed_content(content){
    return $('<div>').html(DOMPurify.sanitize(content)).text().substring(0, 500); // strip html, sanitize
}

export function generate_timestamp(time){
    var date = moment(time, "ddd, DD MMM YYYY HH:mm:ss Z"), today = moment().startOf('day'), timestamp = '';
    if (date.isSame(today, 'day')) return date.format('HH:mm');
    else return date.format('MMM D YYYY');
}