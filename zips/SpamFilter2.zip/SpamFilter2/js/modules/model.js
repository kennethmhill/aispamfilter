import * as DICTIONARY from '../../model/dictionary.js';
import { first20 } from './util.js';

export class Model {

    constructor(encoding_length, threshold, model_json) {
        Object.assign(this, { encoding_length, threshold, model_json });
        this.model = undefined; // init model as undefined
    }

    // words -> tokens -> tensor
    tokenize(words) {
        const tokens = [DICTIONARY.START, ...words.map(word => DICTIONARY.LOOKUP[word] === undefined ? DICTIONARY.UNKNOWN : DICTIONARY.LOOKUP[word])];
        return tf.tensor2d(tokens.concat(Array(this.encoding_length - tokens.length).fill(DICTIONARY.PAD)));
    }

    async load_model() {
        try {
            if (this.model === undefined) this.model = await tf.loadLayersModel(this.model_json);
        } catch (error) {
            console.error('Error loading the model:', error);
            throw error;
        }
    }

    async predict(message) {
        try {
            await this.load_model(); // Use the instance to access the method
            let text = first20(message).toLowerCase().replace(/[^\w\s]/g, ' ').split(' ');
            const tensor = this.tokenize(text); // Use "this" to access the instance method
            const results = await this.model.predict(tensor);
            const data = await results.data();
            return data[1];
        } catch (error) {
            console.error('Error predicting spam probability:', error);
            throw error;
        }
    }

    is_spam(prob) {
        return prob > this.threshold;
    }
}
