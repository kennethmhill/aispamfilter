import { Model } from './model.js';
import { Email } from './email.js';
import { get_trimmed_content, generate_timestamp } from './util.js';
import * as Search from './search.js';

export class Inbox {

    static chuck_size = 20;
    static threshold = .75;

    constructor() {
        Object.assign(this, {
            model: new Model(this.chunk_size, this.threshold),
            current_tab: 0, emails_selected: 0, spam_selected: 0,
            emails: [], spam: [], search_term: ''
        });
    }

    open_tab(index) {
        this.current_tab = index;
        update_mark_all(index, true);
        //if(current_tab == 0 && emails.length == 0) $('#emails .message').text('Inbox is empty.').show();
        //else if(current_tab == 1 && spam.length == 0) $('#spam .message').text('Spam folder is empty. Try running the spam filter.').show();
    }

    async process_emails(results) {
        for (const element of results) {
            try {
                const spam_prob = await Model.predict(element['Subject']);
                console.log('element:'+element);
                this.emails.push(new Email(element['Sender'],element['Subject'],
                                get_trimmed_content(element['Content']),
                                generate_timestamp(element['Date']), spam_prob));
            } catch (error) { console.error('Error processing emails:', error); }
        }
    }

    fill_inbox() {
        var email_container = $('#emails'), spam_container = $('#spam'), content = $("#content");
    
        // append emails to container
        $.each(this.emails, function () {
            email_container.append(this.to_html()); // Call to_html() on the instance
        });
    
        // event delegation (has to be added dynamically if in modules)
        email_container.on('click', '.mark-spam', function (event) { mark_spam($(this).closest('.email').data('email-id'), true) });
        spam_container.on('click', '.mark-not-spam', function (event) { mark_not_spam($(this).closest('.spam').data('email-id'), true) });
        content.on('click', '.email', function (event) { mark($(this).closest('.email').data('email-id'), event) });
    
        email_container.fadeIn(1000);
        $('#emails .message').hide();
    }
    

    update_selected(){
        this.emails_selected = $('.email :checkbox.marked:checked').length;
        this.spam_selected = $('.spam :checkbox.marked:checked').length;
    }

    update_mark_all(i, open){
        if(i == 0){ // emails folder
            if(open){ //tab opened
                if(this.spam_selected > 0) $('#mark-all-not-spam').hide();
                else $('#mark-all-not-spam').fadeOut(300);
            }
            if(this.emails_selected > 0){
                if($('#mark-all-spam').is(":hidden")) $('#mark-all-spam').fadeIn(300);
                $('#mark-all-spam').html('<i class="fa fa-times-circle"></i>Mark Spam ('+this.emails_selected+')');
            }else $('#mark-all-spam').fadeOut(300);
        }else if(i == 1){ // spam folder 
            if(open){//tab opened
                if(this.emails_selected > 0) $('#mark-all-spam').hide();
                else $('#mark-all-spam').fadeOut(300);
            }
            if(this.spam_selected > 0){
                if($('#mark-all-not-spam').is(":hidden")) $('#mark-all-not-spam').fadeIn(300);
                $('#mark-all-not-spam').html('<i class="fa fa-check-circle"></i>Mark Not Spam ('+this.spam_selected+')');
            }else $('#mark-all-not-spam').fadeOut(300);
        }
    }

    update_tabs(animate){
        console.log('here');
        $('#inbox-tab').html('<i class="fa fa-envelope"></i>Inbox <span class="notifications" data-value="'+this.emails.length+'">'+ this.emails.length +'</span>');
        $('#spam-tab').html('<i class="fa fa-flag"></i>Spam <span class="notifications" data-value="'+this.spam.length+'">'+ this.spam.length +'</span>');
        if(animate){
            $('.notifications').each(function () {
                $(this).prop('Counter',0).animate({ Counter: $(this).text()}, { 
                    duration: 1000, easing: 'swing', step: function (now) { $(this).text(Math.ceil(now));}
                });
            });
        }
        $("#loading").hide();
    }

    mark(i, e) {
        if(!$(e.target).is('button')){
            var checkbox = $('[data-email-id="'+i+'"] .marked');
            $(checkbox).prop('checked', !$(checkbox).prop("checked"));
            update_selected();
            update_mark_all(this.current_tab, false);
        }
    }

    search() {
        $('#emails .email').stop().hide();
        $('#spam .spam').stop().hide();
    
        if (this.search_term.length >= 3) {
            if(this.current_tab == 0){
                $('#emails .email').filter(function() { return $(this).text().toLowerCase().includes(this.search_term);})
                                            .highlight(this.search_term).stop().show();
                if($('.email:visible').length == 0) $('#emails .message').text('Nothing found.').show();
                else $('#emails .message').hide();
            }else if(this.current_tab == 1){
                $('#spam .spam').filter(function() { return $(this).text().toLowerCase().includes(this.search_term);})
                                            .highlight(this.search_term).stop().show();
                if($('.spam:visible').length == 0) $('#spam .message').text('Nothing found.').show();
                else $('#spam .message').hide();    
            }
        } else {
            // If search.length < 3, remove highlight
            $('#emails .email').highlight().stop().fadeIn(400);
            $('#spam .spam').highlight().stop().fadeIn(400);
            if(this.current_tab == 0){
                if(this.emails.length == 0) $('#emails .message').text('Inbox is empty.');
                else $('#emails .message').hide();
            }else if(this.current_tab == 1){
                if(this.spam.length == 0) $('#spam .message').text('Spam folder is empty. Try running the spam filter.');
                else $('#spam .message').hide();
            }
        }
    }
}

/* highlight search text */
$.fn.highlight = function(term) {
    return this.each(function() { 
        var content = $(this).html() || '';
        if(typeof term === 'undefined') content = content.replace(/<mark>(.*?)<\/mark>/g, "$1"); // remove highlight if term.length < 3
        else{
            term = term.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&"); // escape special characters
            var pattern = new RegExp("(" + term + ")", "gi");
            content = content.replace(/<mark>(.*?)<\/mark>/g, "$1"); // remove highlight
            content = content.replace(pattern, "<mark>$1</mark>"); // apply highlight
        }
        $element.html(content); // replace content
    });
};

// on document ready
$(function(){
    // init inbox tabs
    $( "#tabs" ).tabs({ active: 0, activate: function (e, ui) { 
        open_tab($("#tabs").tabs("option", "active"));
       }
    });

    // autofilter emails on search
    $('#s').on('input', function () {
        Inbox.search_term = $(this).val().toLowerCase();
        Inbox.search(); // Call the renamed method
    });

    // search focus
    $('#s').on("focus", function(){
        $(this).parent().toggleClass('active');
    });
});
