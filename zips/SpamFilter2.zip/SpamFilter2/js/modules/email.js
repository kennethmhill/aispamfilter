import * as Filter from './filter.js';
import { get_email_colors } from './util.js';

export class Email {

    static email_id = 0;

    constructor(sender, subject, content, timestamp, spam_prob) {
        this.id = ++Email.email_id;
        Object.assign(this, { sender, subject, content, timestamp, spam_prob});
        this.is_spam = spam_prob >= this.threshold;
    }

    to_html(i) {
        var tooltip = '';
        var p = this.spam_prob * 100, colors = get_email_colors();
        var html = '<div class="email" data-email-id="'+ i +'">';
        html += '<button class="mark-spam"><i class="fa fa-times-circle"></i>Mark Spam</button>';
        html += '<button class="mark-not-spam"><i class="fa fa-check-circle"></i>Not Spam</button>';
        html += '<div class="spam_prob hidden" style="background:'+colors[0]+'; border:1px solid '+colors[1]+';" data-value="'+Math.ceil(p)+'"><i class="fa fa-ban"></i>'+ p.toFixed(2) +'%'+tooltip+'</div>';
        html += '<div class="check"><input class="marked" id="cbx-'+i+'" type="checkbox" style="display: none;"/><label class="cbx" for="cbx-'+i+'"><span><svg width="12px" height="9px" viewbox="0 0 12 9"><polyline points="1 5 4 8 11 1"></polyline></svg></span></label></div>';
        html += '<div class="sender">' + this.sender + '</div>';
        html += '<div class="subject">'+ this.subject + '</div>';
        html += '<div class="excerpt">' + this.content + '</div>';
        html += '<div class="timestamp">' + this.timestamp + '</div>';
        html += '</div>';
        return html;
    }

    // predict
    async predict(){
        return await Filter.predict(this.subject);
    }

    // find email index by id
    get_email_index(id) {
        for (var i = 0; i < this.emails.length; i++)
            if (this.emails[i].id === id) return i;
        return -1; // Return -1 if the email is not found
    }

    get_spam_index(id) {
        for (var i = 0; i < this.spam.length; i++)
            if (this.spam[i].id === id) return i;
        return -1; // email not found
    }

    mark_spam(id, notify) {

        var email_index = get_email_index(id),
                          selector = '[data-email-id="'+id+'"]', 
                          message = this.emails.splice(email_index, 1)[0];
    
        $(selector + ' .marked').prop('checked', false); 
    
        this.spam.push(message); // push to spam
        update_selected(); // update 
        update_mark_all(this.current_tab, false); 
        update_tabs(false);
    
        $(selector).toggleClass('email spam');
        $(selector).appendTo('#spam');
    
        if (this.emails.length === 0) $('#emails .message').text('Inbox is empty.').show();
        else if ($('.email:visible').length == 0) $('#emails .message').text('Nothing found.').show();
        if (this.spam.length === 1) $('#spam .message').hide();
        if(notify) $.notify("Conversation marked as spam", { className: "success", autoHideDelay: 9000 });
    }

    mark_not_spam(id, notify) {
        var spam_index = get_spam_index(id), 
            selector = '[data-email-id="'+id+'"]',
            message = this.spam.splice(spam_index, 1)[0];
    
        $(selector + ' .marked').prop('checked', false); 
    
        this.emails.push(message);
        update_selected();
        update_mark_all(this.current_tab, false);
        update_tabs(false);
    
        $(selector).toggleClass('email spam');
        $(selector).prependTo('#emails');
    
        if (this.spam.length === 0) $('#spam .message').text('Spam folder is empty. Try running the spam filter.').show();
        else if ($('.spam:visible').length == 0) $('#spam .message').text('Nothing found.').show();
        if (this.emails.length === 1) $('#emails .message').hide();
        if(notify) $.notify("Conversation moved back to inbox.", { className: "success", autoHideDelay: 9000 });
    }

    mark_all_spam(){
        var selection = $('.email :checkbox.marked:checked');
        $.each(selection, function(i, e){
            var email = $(e).parents('.email'), email_id = $(email).data('email-id');
            mark_spam(email_id, false);
        });
        $.notify(selection.length + " conversations moved to spam folder.", { className: "success", autoHideDelay: 3000 });
    }
    
    mark_all_not_spam(){
        var selection = $('.spam :checkbox.marked:checked').get().reverse();    
        $.each(selection, function(i, e){
            var email = $(e).parents('.spam'), email_id = $(email).data('email-id');
            mark_not_spam(email_id, false);
        });
        $.notify(selection.length + " conversations moved to spam folder.", { className: "success", autoHideDelay: 3000 });
    }
}