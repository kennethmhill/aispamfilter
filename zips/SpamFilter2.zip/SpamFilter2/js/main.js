import * as Util from './modules/util.js';
import * as Email from './modules/email.js';
import * as Inbox from './modules/inbox.js';
import * as Model from './modules/model.js';
import * as Filter from './modules/filter.js';

$(function() {
    $("#loading").fadeIn(1000);
    $("#sidebar").fadeIn(1000);

    var inbox = new Inbox.Inbox();
    var model = new Model.Model();

    model.load_model() // Load AI model
        
});
