PhantomFilter V2 by Kenneth Hill
****************
INST364 Final Project

Updates
- tried refactoring the code into modules/classes, very close but a few more errors

Instructions
- open terminal, navigate to project folder
- install dependencies
    - "npm install @tensorflow/tfjs"
    - "npm install @natural"
- run simple-http server
    - python3 -m http.server 3000
- visit localhost:3000
