var email_id = 0;
var emails = [];
var spam = [];

var black_list = [];
var white_list = [];

var emails_selected = 0;
var spam_selected = 0;

var current_tab = 0;
var search = '';

$(function() {
    $("#loading").fadeIn(1000);
    $("#sidebar").fadeIn(1000);
    $("#heuristics").button();
    $("#rbl").button();

    fetchResults()
    .then(function(results) {
        process_emails(results);
        // TODO: spam process function goes here
        fill_inbox(emails);
        update_tabs(true);
        $("#loading").hide();
    })
    .fail(function(jqXHR, textStatus, errorThrown) {
        console.error('Error fetching results:', errorThrown);
    });

    //init ui
    $( "#tabs" ).tabs({ 
        active: 0,
        activate: function (event, ui) {
            open_tab($("#tabs").tabs("option", "active"));
        }
    });

    $("#detect").click(function(){
        black_list = $('#blacklist').val().split(/[,\n]/).map(
            function(item) {
                return item.trim().toLowerCase();
            }).filter(function(element) {
                return element !== '';
            });
        white_list = $('#whitelist').val().split(/[,\n]/).map(
            function(item) {
                return item.trim().toLowerCase();
            }).filter(function(element) {
                return element !== '';
            });
        filter_lists(); // omit matching whitelist/blacklist terms
        filter_emails(); // filter with blacklist/whitelist
    });

    // search focus
    $('#s').on("focus", function(){
        $(this).parent().toggleClass('active');
    });
    
    // autofilter emails
    $('#s').on('input', function(){
        var s = $(this).val().toLowerCase();
        search = s;
        search_emails();
    });

    $('#heuristics').change(function() {
        if(this.checked){
            $.notify("Bayesian filtering is in development.",
                {
                    className: "info",
                    autoHideDelay: 3000
                });
        }
    });
    $('#rbl').change(function() {
        if(this.checked){
            $.notify("Real-time block lists in development.",
                {
                    className: "info",
                    autoHideDelay: 3000
                });
        }
    });
});

function search_emails() {
    /* term is at least 3 chars */
    $('#emails .email').stop().hide();
    $('#spam .spam').stop().hide();

    if (search.length >= 3) {
        if(current_tab == 0){
            $('#emails .email').filter(function() {
                return $(this).text().toLowerCase().includes(search);
            }).highlight(search).stop().show();
            if($('.email:visible').length == 0) $('#emails .message').text('Nothing found.').show();
            else $('#emails .message').hide();
        }else if(current_tab == 1){
            $('#spam .spam').filter(function() {
                return $(this).text().toLowerCase().includes(search);
            }).highlight(search).stop().show();
            if($('.spam:visible').length == 0) $('#spam .message').text('Nothing found.').show();
            else $('#spam .message').hide();    
        }
    } else {
        // If the search term is less than three characters, remove highlighting
        $('#emails .email').highlight().stop().fadeIn(400);
        $('#spam .spam').highlight().stop().fadeIn(400);
        if(current_tab == 0){
            if(emails.length == 0) $('#emails .message').text('Inbox is empty.');
            else $('#emails .message').hide();
        }else if(current_tab == 1){
            if(spam.length == 0) $('#spam .message').text('Spam folder is empty. Try running the spam filter.');
            else $('#spam .message').hide();
        }
    }
}

/* highlight text */
(function($) {
    $.fn.highlight = function(term) {
        return this.each(function() {
            var $element = $(this);
            var content = $element.html() || '';
            // term < 3 chars, remove highlight
            if(typeof term === 'undefined') content = content.replace(/<mark>(.*?)<\/mark>/g, "$1");
            else{ //term >= 3 chars
                term = term.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&"); // Escape special characters in the term
                content = content.replace(/<mark>(.*?)<\/mark>/g, "$1"); // remove highlight
                var pattern = new RegExp("(" + term + ")", "gi");
                content = content.replace(pattern, "<mark>$1</mark>"); // apply highlight
            }
            $element.html(content); // replace content
        });
    };
})(jQuery);

function open_tab(index) {
    current_tab = index;
    update_mark_all(index, true);
    //if(current_tab == 0 && emails.length == 0) $('#emails .message').text('Inbox is empty.').show();
    //else if(current_tab == 1 && spam.length == 0) $('#spam .message').text('Spam folder is empty. Try running the spam filter.').show();
}

function blacklist(terms){
    var count = 0;
    if(terms.length == 0 || terms[0] == '') return;
    $(emails).each(function(index, email) {
        var contains_spam = terms.some(function(word) {
            console.log('testing word: ' + word);
            return email.sender.toLowerCase().includes(word.trim().toLowerCase()) ||
                   email.subject.toLowerCase().includes(word.trim().toLowerCase()) ||
                   email.content.toLowerCase().includes(word.trim().toLowerCase());
        });
        if(contains_spam){
            mark_spam(email.id, false);
            count++;
        }
    });
    if(!count) $.notify("Nothing blacklisted. Try adjusting the settings.",
                {
                    className: "warn",
                    autoHideDelay: 3000
                });
    else{
        $.notify(count + " conversation(s) added to spam.",
                {
                    className: "success",
                    autoHideDelay: 3000
                });
        update_tabs(true);
        update_mark_all(current_tab, false);
    }
}

function whitelist(terms){
    var count = 0;
    if(terms.length == 0 || terms[0] == '') return;
    $(spam).each(function(index, message) {
        var contains_whitelist = terms.some(function(word) {
            console.log('testing word: ' + word);
            return message.sender.toLowerCase().includes(word.trim().toLowerCase()) ||
                message.subject.toLowerCase().includes(word.trim().toLowerCase()) ||
                message.content.toLowerCase().includes(word.trim().toLowerCase());
        });
        if(contains_whitelist){
            console.log('contains spam');
            mark_not_spam(message.id, false);
            count++;
        }
    });
    if(!count) $.notify("Nothing whitelisted. Try adjusting the settings.",
                {
                    className: "warn",
                    autoHideDelay: 3000
                });
    else{
        $.notify(count + " conversation(s) moved to inbox.",
                {
                    className: "success",
                    autoHideDelay: 3000
                });
        
        update_tabs(true);
        update_mark_all(current_tab, false);
    }
}

function filter_emails(){
    if(black_list.length > 0) blacklist(black_list);
    if(white_list.length > 0) whitelist(white_list);
}

function fetchResults() {
    return $.ajax({
        url: 'csv/emails.csv', // Replace with the path to your CSV file
        dataType: 'text', // Specify the data type as text
    }).then(function(data) {
        // Convert CSV to JSON using jQuery CSV plugin
        return $.csv.toObjects(data);
    });
}

// Function to process results
function process_emails(results) {
    //var text = $('<div>').html(content).text({ decodeEntities: true });
    emails = results.map(function(element) {
        return {
            id: generate_id(),
            sender: element['Sender'],
            subject: element['Subject'],
            timestamp: get_timestamp(element['Date']),
            content: get_trimmed_content(element['Content'])
        };
    });
}
function generate_id() {
    return (email_id++);
}

function fill_inbox(emails){
    $.each(emails, function(index, element) {
        var email = build_email_html(element.id, element);
        $('#emails').append(email);
        $('#emails').fadeIn(1000);
    });
    $('#emails .message').hide();
}

function filter_lists(){
    var omit_terms = $.grep(white_list, function(term) {
        return $.inArray(term.toLowerCase(), black_list) !== -1;
    });
    if(omit_terms.length > 0){
        terms = omit_terms.join(', ');
        $.notify("The following terms were found in both the whitelist and the blacklist, and will be omitted from the spam filter: " + terms,
        {
            className: "info",
            autoHideDelay: 20000
        });
    }
    $.each(omit_terms, function(index, term) {
        var i1 = white_list.indexOf(term);
        var i2 = black_list.indexOf(term);

        if (i1 !== -1){
            white_list.splice(i1, 1);
        }
        if (i2 !== -1){
            black_list.splice(i2, 1);
        } 
    });
}


// Function to populate div with dynamic content
function build_email_html(index, email) {
    html = '<div class="email" data-email-id="'+ index +'" onclick="mark('+index+', event)">';
    html += '<button class="mark-spam" onclick="mark_spam('+index+', true)"><i class="fa fa-times-circle"></i>Mark Spam</button>';
    html += '<button class="mark-not-spam" onclick="mark_not_spam('+index+', true)"><i class="fa fa-check-circle"></i>Not Spam</button>';
    //html += '<div class="check"><input type="checkbox" class="marked"><label for="marked"><div class="tick_mark"></div></label></div>';
    html += '<div class="check"><input class="marked" id="cbx-'+index+'" type="checkbox" style="display: none;"/><label class="cbx" for="cbx-'+index+'"><span><svg width="12px" height="9px" viewbox="0 0 12 9"><polyline points="1 5 4 8 11 1"></polyline></svg></span></label></div>';
    html += '<div class="sender">' + email['sender'] + '</div>';
    html += '<div class="subject">'+email['subject'] + '</div>';
    html += '<div class="excerpt">' + email['content'] + '</div>';
    html += '<div class="timestamp">' + email['timestamp'] + '</div>';
    html += '</div>';
    //$(html).find('img').addClass('lazy'); // dont need because html tags are stripped
    return html;
}

function get_trimmed_content(content){
    content = DOMPurify.sanitize(content);
    var text = $('<div>').html(content).text(); // strip html tags
    var first500 = text.substring(0, 500);
    return first500;
}
function get_timestamp(time){
    var date = moment(time, "ddd, DD MMM YYYY HH:mm:ss Z");
    var today = moment().startOf('day');
    timestamp = '';
    if (date.isSame(today, 'day')) timestamp = date.format('HH:mm');
    else timestamp = date.format('MMM D YYYY');
    return timestamp;
}

/*function add_spam(id) {
    var message = emails.splice(id, 1)[0];
    var email_index = get_email_index(id);
    emails.splice(email_index,1);
    spam.push(message);
    var container = build_email_html(id,message);
    //console.log('data -- spam.length: ' + spam.length + ', container: ' + JSON.stringify(container));
    if (spam.length === 1) $('#spam').html(container);
    else container.appendTo('#spam');
    $('[data-email-id="'+id+'"]').toggleClass('email spam');

    if (emails.length === 0) $('#emails').html('<div class="empty-message">Inbox is empty.</div>');
}*/

// Function to find the index of an email in the emails array by its ID
function get_email_index(email_id) {
    for (var i = 0; i < emails.length; i++) {
        if (emails[i].id === email_id) {
            return i;
        }
    }
    return -1; // Return -1 if the email is not found
}
function get_spam_index(email_id) {
    for (var i = 0; i < spam.length; i++) {
        if (spam[i].id === email_id) {
            return i;
        }
    }
    return -1; // Return -1 if the email is not found
}

function mark_spam(email_id, notify) {
    var email_index = get_email_index(email_id);
    var selector = '[data-email-id="'+email_id+'"]';
    $(selector + ' .marked').prop('checked', false); 
    var message = emails.splice(email_index, 1)[0];
    spam.push(message);
    update_selected();
    update_mark_all(current_tab, false);
    update_tabs(false);
    var container = $(selector);
    container.toggleClass('email spam');
    if (spam.length === 1) $('#spam .message').hide();
    container.appendTo('#spam');
    if (emails.length === 0) $('#emails .message').text('Inbox is empty.').show();
    else if ($('.email:visible').length == 0) $('#emails .message').text('Nothing found.').show();
    if(notify) $.notify("Conversation marked as spam",
        {
            className: "success",
            autoHideDelay: 9000
        });
}

function mark_all_spam(){
    selection = $('.email :checkbox.marked:checked')
    $.each(selection, function(index, element){
        var email = $(element).parents('.email');
        var email_id = $(email).data('email-id');
        mark_spam(email_id, false);
    });
    $.notify(selection.length + " conversations moved to spam folder." + terms,
        {
            className: "success",
            autoHideDelay: 3000
        });
}

function mark_not_spam(email_id, notify) {
    var spam_index = get_spam_index(email_id);
    var selector = '[data-email-id="'+email_id+'"]';
    $(selector + ' .marked').prop('checked', false); 
    var message = spam.splice(spam_index, 1)[0];
    emails.push(message);
    update_selected();
    update_mark_all(current_tab, false);
    update_tabs(false);
    var container = $(selector);
    container.toggleClass('email spam');
    if (emails.length === 1) $('#emails .message').hide();
    container.prependTo('#emails');
    if (spam.length === 0) $('#spam .message').text('Spam folder is empty. Try running the spam filter.').show();
    else if ($('.spam:visible').length == 0) $('#spam .message').text('Nothing found.').show();
    if(notify) $.notify("Conversation moved back to inbox.",
        {
            className: "success",
            autoHideDelay: 9000
        });
}

function mark_all_not_spam(){
    selection = $('.spam :checkbox.marked:checked')       
    $(selection.get().reverse());
    $.each(selection, function(index, element){
        var email = $(element).parents('.spam');
        var email_id = $(email).data('email-id');
        mark_not_spam(email_id, false);
    });
    $.notify(selection.length + " conversations moved to spam folder.",
        {
            className: "success",
            autoHideDelay: 3000
        });
    
}

function mark(email_id, event) {
    if(!$(event.target).is('button')){
        var checkbox = $('[data-email-id="'+email_id+'"] .marked');
        $(checkbox).prop('checked', !$(checkbox).prop("checked"));
        update_selected();
        update_mark_all(current_tab, false);
    }
}

function update_mark_all(index, open){
    if(index == 0){ // emails folder
        if(open){ //tab opened
            if(spam_selected > 0) $('#mark-all-not-spam').hide();
            else $('#mark-all-not-spam').fadeOut(300);
        }
        if(emails_selected > 0){
            if($('#mark-all-spam').is(":hidden")) $('#mark-all-spam').fadeIn(300);
            $('#mark-all-spam').html('<i class="fa fa-times-circle"></i>Mark Spam ('+emails_selected+')');
        }else $('#mark-all-spam').fadeOut(300);
    }else if(index == 1){ // spam folder 
        if(open){//tab opened
            if(emails_selected > 0) $('#mark-all-spam').hide();
            else $('#mark-all-spam').fadeOut(300);
        }
        if(spam_selected > 0){
            if($('#mark-all-not-spam').is(":hidden")) $('#mark-all-not-spam').fadeIn(300);
            $('#mark-all-not-spam').html('<i class="fa fa-check-circle"></i>Mark Not Spam ('+spam_selected+')');
        }else $('#mark-all-not-spam').fadeOut(300);
    }
}

function update_selected(){
    emails_selected = $('.email :checkbox.marked:checked').length;
    spam_selected = $('.spam :checkbox.marked:checked').length;
    console.log('e: ' + emails_selected + ', spam:' + spam_selected);
}


function update_tabs(animate){
    $('#inbox-tab').html('<i class="fa fa-envelope"></i>Inbox <span class="notifications" data-value="'+emails.length+'">'+ emails.length +'</span>');
    $('#spam-tab').html('<i class="fa fa-flag"></i>Spam <span class="notifications" data-value="'+spam.length+'">'+ spam.length +'</span>');
    if(animate){
        $('.notifications').each(function () {
            $(this).prop('Counter',0).animate({
                Counter: $(this).text()
            }, {
                duration: 1000,
                easing: 'swing',
                step: function (now) {
                    $(this).text(Math.ceil(now));
                }
            });
        });
    }
}
/*
function detectSpam() {
    const emailInput = document.getElementById('emailInput').value;
    const emails = emailInput.split(',');
    const spamKeywords = ['spam', 'sale', 'offer', 'free'];
    const spamResults = [];

    emails.forEach(email => {
        const isSpam = spamKeywords.some(keyword => email.toLowerCase().includes(keyword));
        spamResults.push({ email, isSpam });
    });

    displayResults(spamResults);
}

function displayResults(results) {
    const resultsList = document.getElementById('results');
    resultsList.innerHTML = '';

    results.forEach(result => {
        const listItem = document.createElement('li');
        listItem.textContent = `${result.email} - ${result.isSpam ? 'Spam' : 'Not Spam'}`;
        resultsList.appendChild(listItem);
    });
}*/