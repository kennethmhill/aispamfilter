import * as DICTIONARY from '/model/dictionary.js';

const ENCODING_LENGTH = 20; // max number of words 
const MODEL_JSON_URL = '/model/model.json'; // URL of the model.json file 
const SPAM_THRESHOLD = 0.75; // minimum confidence for spam to be flagged
var model = undefined;

/** 
 * takes an array of words, converts words to tokens, returns tensor
 */
function tokenize(words) {
    let tokens = [DICTIONARY.START]; // push start token

    for (var i = 0; i < words.length; i++) tokens.push(DICTIONARY.LOOKUP[words[i]] === undefined ? DICTIONARY.UNKNOWN : DICTIONARY.LOOKUP[words[i]]); // encode words with dictionary
    
    while (tokens.length < ENCODING_LENGTH) tokens.push(DICTIONARY.PAD); // pad empty space

    return tf.tensor([tokens]); // convert to Tensor
}

/** 
 * load the model and predict if given input is spam 
**/
async function predict(message) {
  try {
    let text = first20(message).toLowerCase().replace(/[^\w\s]/g, ' ').split(' ');
    const tensor = tokenize(text);    
    const results = await model.predict(tensor);
    const data = await results.data();    
    return data[1];
  } catch (error) {
    console.error('Error predicting spam probability:', error);
    throw error; // Rethrow the error to handle it in the calling function
  }
}

function first20(text) {
  var words = text.split(/\s+/);
  var message = words.slice(0, 20).join(' ');
  return message;
}


function is_spam(prob_spam){
  if (prob_spam > SPAM_THRESHOLD) return true;
  else return false;
}

// Add console log to check if the model is loaded successfully
async function load_model() {
  if (model === undefined) model = await tf.loadLayersModel(MODEL_JSON_URL);
}

export {load_model, predict, is_spam, SPAM_THRESHOLD};